import React from "react";

export default function Solicitacoes() {
  return (
    <div>
      <h1>Solicitações</h1>
      <p>Página de Solicitações</p>
    </div>
  );
}