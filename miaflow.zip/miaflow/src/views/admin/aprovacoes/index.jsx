import React from "react";

export default function Aprovacoes() {
  return (
    <div>
      <h1>Aprovações</h1>
      <p>Página de Aprovações</p>
    </div>
  );
}