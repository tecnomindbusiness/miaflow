import React from "react";

export default function Atividades() {
  return (
    <div>
      <h1>Atividades</h1>
      <p>Página de Atividades</p>
    </div>
  );
}