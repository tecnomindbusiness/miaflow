import React from "react";

// Chakra imports
import { Flex, Text, useColorModeValue } from "@chakra-ui/react";

// Custom components
// import { HorizonLogo } from "components/icons/icon.png";
import HorizonLogo from "components/icons/icon.png";
import { HSeparator } from "components/separator/Separator";

export function SidebarBrand() {
  //   Chakra color mode
  let logoColor = useColorModeValue("navy.700", "white");

  return (
    <Flex align="left" direction="column">
      <Flex align="center" direction="row">
        <img
          src={HorizonLogo}
          alt="Horizon Logo"
          style={{
            height: "50px",
            width: "50px",
            marginTop: "5px",
            marginBottom: "5px",
            filter: logoColor === "white" ? "invert(1)" : "none",
          }}
        />
        <Text
          fontSize="xl"
          fontWeight="bold"
          color={logoColor}
          ml="10px" // Espaço entre a logo e o texto
        >
          GITIA.flow
        </Text>
      </Flex>
      <HSeparator mb="20px" />
    </Flex>
  );
}

export default SidebarBrand;
